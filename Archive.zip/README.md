# Chrome Extension for AWS API Debugger

Not everyone use AWS SDK to use AWS APIs, and when you want to directly interact with AWS low level APIs it is a very painful experience. Services signature, parameters, element, etc., will exhaust all your enthusiasm in some no your core business logic. "Chrome AWS API Debugger" will give you a tool to debug directly with AWS APIs and not to do the things you don't want to do.

Version 0.1.0: Init Version

Chrome plugin: https://chrome.google.com/webstore/detail/chrome-aws-api-debugger/mohdimfdnhinneooofaoiklhaeebkbgb